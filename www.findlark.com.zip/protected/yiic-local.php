<?php
set_time_limit(0);

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../framework/yiic.php';
$config=dirname(__FILE__).'/config/main-local.php';

require_once($yiic);

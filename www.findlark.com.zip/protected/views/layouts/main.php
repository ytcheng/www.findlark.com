<?php $this->beginContent('//layouts/public'); ?>
<?php echo $content; ?>
<script type="text/javascript">
	
</script>
<?php $this->endContent(); ?>
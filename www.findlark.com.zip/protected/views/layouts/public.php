<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns='http://www.w3.org/1999/xhtml'>
	<head>
		<title>FindLark</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="keywords" content="FindLark,BYFX,Lark">
		
		<link rel="stylesheet" type="text/css" href="/static/css/public.css">
		<link rel="stylesheet" type="text/css" href="/static/css/<?php echo $this->id;?>.css">
		
		<script type="text/javascript" src="/static/js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript" src="/static/js/jquery.masonry.js"></script>
	</head>
	<body>
		<?php echo $content;?>
		
		<div style="display:none">
			<script type="text/javascript">
				var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
				document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F94f327e06e5b39be23fa5d95315a897f' type='text/javascript'%3E%3C/script%3E"));
			</script>
		</div>
	</body>
</html>
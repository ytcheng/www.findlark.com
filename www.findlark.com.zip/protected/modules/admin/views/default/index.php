<div>
	<div>添加扩展</div>
	<form action="/admin/defalut/tool" method="post" enctype="multipart/form-data">
		文件: <input type="file" name="file"><br>
		标题：<input type="text" name="title" value="test gallery"><br>
		
		<input type="submit" value="提交">
	</form>
</div>